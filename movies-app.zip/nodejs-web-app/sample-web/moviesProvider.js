var AzureEndpoint = require('azureEndpoints').AzureEndpoint;
var mongoDb = require('mongodb').Db;
var mongoDbConnection = require('mongodb').Connection;
var mongoServer = require('mongodb').Server;
var bson = require('mongodb').BSONNative;
var objectID = require('mongodb').ObjectID;

var MoviesProvider = function() {
  var self = this;

  // TODO: insert code here
};

MoviesProvider.prototype.getCollection = function(callback) {
  var self = this;

  var ensureMongoDbConnection = function(callback) {
    if (self.db.state !== 'connected') {
      self.db.open(function (error, client) {
        callback(error);
      });
    } else {
      callback(null);
    }
  }

  ensureMongoDbConnection(function(error) {
    if (error) {
      callback(error);
    } else {
      self.db.collection('movies', function(error, movies_collection) {
        if (error) {
          callback(error);
        } else {
          callback(null, movies_collection);
        }
      });
    }
  });
};

MoviesProvider.prototype.findAll = function(callback) {
  this.getCollection(function(error, movies_collection) {
    if (error) {
      callback(error)
    } else {
      movies_collection.find().toArray(function(error, results) {
        if (error) {
          callback(error);
        } else {
			callback(null, results);
        }
      });
    }
  });
};

MoviesProvider.prototype.fillCollectionIfEmpty = function(client){

	client.createCollection('movies', function(err, collection){
		collection.find().toArray(function(err, results){
			if(results.length == 0){
				var movies = new Array();
				console.log('inserting values into\n');
				console.log(self.db);
				movies.push({ 'Title':'Rocky', 'Genre':'Action', 'Date':'1976' });
				movies.push({ 'Title':'Back to the Future', 'Genre':'Science Fiction', 'Date':'1985' });
				movies.push({ 'Title':'Top Gun', 'Genre':'Action', 'Date':'1986' });
				movies.push({ 'Title':'El secreto de sus ojos', 'Genre':'Drama/Thriller', 'Date':'2009' });
				movies.push({ 'Title':'The Godfather', 'Genre':'Crime/Drama', 'Date':'1972' });
				collection.insert(movies, function(err,res){});
			}
		});
	});
};

exports.MoviesProvider = MoviesProvider;